/***
 * This example expects the serial port has a loopback on it.
 *
 * Alternatively, you could use an Arduino:
 *
 * <pre>
 *  void setup() {
 *    Serial.begin(<insert your baudrate here>);
 *  }
 *
 *  void loop() {
 *    if (Serial.available()) {
 *      Serial.write(Serial.read());
 *    }
 *  }
 * </pre>
 */

//library
#include <ros/ros.h>
#include <serial/serial.h>
#include <std_msgs/String.h>
#include <std_msgs/Empty.h>
#include <stdint.h>
#include <iostream>

//rtcm msg header
//wave_pkg가 먼저 catkin_make 되어야 빌딩 됨. 왜냐하면 이게 메시지 gen이 되어야 하기 때문이다.
#include <wave_pkg/RTCM.h>
#include <wave_pkg/RTCMheader.h>
#include <wave_pkg/RTCMmessageList_t.h>

/*
 * RTCM 넘기는 프로그램 190331 jiwan
 * 1. sudo chmod 777 을 사용하여 시리얼 포트 개방해준다.
 * 2. 이 rtcm_driver 안에 있는 런치파일에서 포트를 설정해준다.
 * 3. 115200 은 기본이니 건들 필요가 아마 거의 없음
 * 4. 이 코드에 대한 설명 :
 *      1) 우선 시리얼 포트를 개방한다.
 *      2) ser.setPort(setPortName); // ACM0 에서 USB0 으로 수정함. "/dev/ttyUSB0"
            ser.setBaudrate(BaudrateNum); // 비트레이트 수정함.
            serial::Timeout to = serial::Timeout::simpleTimeout(hzNum_I);
            ser.setTimeout(to);
             ser.open();
             등을 사용해서 개방해줌.
        3) 그리고 ros::spin() 으로 콜백함수가 들어오는 즉시 ser.write() 를 해준다
        4) 이때 ser.write()는 serial 통신으로 gps에 정보를 전달해준다.
        5) 즉, wave에서 rtcm만 받고 바로 시리얼 통신으로 입력해줌.
 * 5. 기타
 *      콜백함수에 무슨 cout 여러개가 있는데 디버깅하기 위해서 적었지만 사실 없어도 된다.
 *      제일 중요한건 ser.write(rtcmMsg.ui8_RtcmMsgs); 이다.
 */

using namespace std;

class RawRTCM
{
private:
    serial::Serial ser;
    std::string setPortName;
    int BaudrateNum;
    int hzNum_I;
    double hzNum_D;
    std::vector<uint8_t> _8bitsData;

    ros::NodeHandle nh;
    ros::NodeHandle pnh;

    ros::Subscriber RTCM_sub;
public:
    RawRTCM(ros::NodeHandle &nhParam)
    :BaudrateNum(115200), hzNum_I(100), hzNum_D(100), pnh("~"), nh(nhParam)
    {
        pnh.param<std::string>("setPort", setPortName, "/dev/ttyACM0");
        pnh.param<int>("setBaudrate", BaudrateNum, 115200);
        //    pnh.param<int>("setHz", hzNum_I, 100);
        RTCM_sub = nh.subscribe("/wave/rtcm_message", 10, &RawRTCM::RTCM_callback, this);
    }

    void RTCM_callback(const wave_pkg::RTCM::ConstPtr &msg)
    {
//        cout << 1 << endl;
        wave_pkg::RTCM rtcmMsg = *msg;
//    cout << " rtcmMsg.ui8_RtcmMsgs.size() : " << rtcmMsg.ui8_RtcmMsgs.size() << endl;
//    cout << " msg.ui8_RtcmMsgs.size() : " << msg->ui8_RtcmMsgs.size() << endl;
//    cout << "for start" << endl;
        for (int i = 0; i < rtcmMsg.ui8_RtcmMsgs.size(); ++i)
        {
            ROS_INFO("rtcmMsg.ui8_RtcmMsgs[i]:  %02X, i : %d" , rtcmMsg.ui8_RtcmMsgs[i], i);
        }

        ser.write(rtcmMsg.ui8_RtcmMsgs);
//    cout << "for end" << endl;
    }

    int serial_Open()
    {
        try
        {
            ser.setPort(setPortName); // ACM0 에서 USB0 으로 수정함. "/dev/ttyUSB0"
            ser.setBaudrate(BaudrateNum); // 비트레이트 수정함.
            serial::Timeout to = serial::Timeout::simpleTimeout(hzNum_I);
            ser.setTimeout(to);
            ser.open();
        }
        catch (serial::IOException& e)
        {
            ROS_ERROR_STREAM("Unable to open port ");
            return -1;
        }


        if(ser.isOpen())
        {
            ROS_INFO_STREAM("Serial Port initialized");
        }
        else
        {
            return -1;
        }
    }
};


int main (int argc, char** argv){
    ros::init(argc, argv, "rawRTCM_send8bitsDataUsingVector");
    ros::NodeHandle nh;
    RawRTCM rawRTCM(nh);
    if(rawRTCM.serial_Open() == -1)
    {
        ROS_ERROR("The End");
    }
    ros::spin();

}

